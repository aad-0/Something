DO not fucking use the ioctlwrapper in other projects, or I will find you I will do things that you would not want to remember
